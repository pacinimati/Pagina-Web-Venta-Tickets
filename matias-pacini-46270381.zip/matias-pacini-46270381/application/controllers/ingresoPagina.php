<?php

defined('BASEPATH') OR exit('No direct script access allowed');


///MUESTRA PRINCIPAL MERCADOLIBRE Y SUS #


class IngresoPagina extends CI_Controller {
    
    public function index() {
        // Carga el modelo
        $this->load->model('InsertarArticulo');
        
        // Obtiene solo 3 artículos
        $data_art['artic'] = $this->InsertarArticulo->getArticuloCant();
        
        // Carga las vistas y pasa los datos
        $this->load->view('home/cabecera');
        $this->load->view('home/mercadolibre', $data_art);
    }
}

