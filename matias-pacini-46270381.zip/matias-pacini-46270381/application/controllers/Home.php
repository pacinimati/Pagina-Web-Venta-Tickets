<?php

defined('BASEPATH') OR exit('No direct script access allowed');


///MUESTRA PRINCIPAL MERCADOLIBRE Y SUS #


class Home extends CI_Controller {
    
    public function mercadolibre($fragmento = '') {

        // Cargar la vista con el fragmento
        $this->load->view('home/cabecera');
        $this->load->view('home/mercadolibre', ['fragmento' => $fragmento]);
    }
}
