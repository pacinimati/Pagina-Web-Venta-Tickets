<?php

defined('BASEPATH') OR exit('No direct script access allowed');


///MUESTRA PRINCIPAL MERCADOLIBRE Y SUS #


class Modoadmin extends CI_Controller {
    
    public function index() {
        
        
        $this->load->view('home/cabeceraAdmin');
        $this->load->view('home/mercadolibreAdmin');
    }
}