<?php
defined('BASEPATH') OR exit('No direct script access allowed');

///MUESTRA USERS

class MostrarUsers extends CI_Controller {

	function __construct() { 
        parent::__construct();
        $this->load->model('UserModel');
    }

    public function index()
    {

        $users = $this->UserModel->get_all_users();

        $mainData = [
            'users' => $users
        ];

        $this->load->view('home/cabeceraAdmin',$mainData);

        $this->load->view('home/mostrarUsers',$mainData);

    }
}