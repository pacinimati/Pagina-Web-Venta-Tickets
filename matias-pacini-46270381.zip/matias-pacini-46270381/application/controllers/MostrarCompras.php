<?php
defined('BASEPATH') OR exit('No direct script access allowed');

///MUESTRA USERS

class MostrarCompras extends CI_Controller {

	function __construct() { 
        parent::__construct();
        $this->load->model('Comprasmodel');
    }

    public function index()
    {

        $compras = $this->Comprasmodel->get_all_compras();

        $mainData = [
            'compras' => $compras
        ];

        $this->load->view('home/cabeceraAdmin');

        $this->load->view('home/mostrarCompras',$mainData);

    }
}