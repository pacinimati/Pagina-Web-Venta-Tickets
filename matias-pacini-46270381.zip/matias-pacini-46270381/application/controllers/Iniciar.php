<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Iniciar extends CI_Controller {

    public function index()
    {
        // Muestra la vista de inicio de sesión sin mensajes de error por defecto
        $dato['conforme'] = ""; // Inicializa el mensaje de error
        $this->load->view('home/ingresoSistema', $dato);
    }

    public function ValidaUsuario()
    {
        // Verifica si se ha enviado el formulario
        if ($this->input->post()) {
            // Recibe los datos de usuario y clave
            $usuario = $this->input->post('usuario'); 
            $pass = $this->input->post('clave');

            // Carga el modelo
            $this->load->model('ModeloPrueba');

            // Validar usuario con el modelo
            $resultado = $this->ModeloPrueba->validaIngreso($usuario, $pass);

            // Verifica si el usuario es válido
            if ($resultado && $resultado->num_rows() > 0) {
                // Si el usuario es válido, redirige a la vista "mercadolibre"
                $this->load->view('home/cabeceraAdmin');
                $this->load->view('home/mercadolibreAdmin');
            } else {
                // Si no es un usuario válido, muestra un mensaje de error
                $dato['conforme'] = "$usuario no es usuario del sistema, o ingresó mal la clave";
                $this->load->view('home/ingresoSistema', $dato);
            }
        } else {
            // Si no se ha enviado ningún dato, simplemente muestra la vista de inicio
            $this->index();
        }
    }
}

