<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class OperarDatos extends CI_Controller {



    public function GrabarCliente(){
            
        /*Recibe los datos de user y pass y tiene que validarlos*/
        
        $nombre = $this->input->post('nombre');
        
        $clave = $this->input->post('clave');

        $this->load->model('InsertarCliente');
        $this->InsertarCliente->guardarCliente($nombre,$clave);
        redirect('MostrarUsers');
    }



    
    public function cargarArticuloView() {
        $this->load->view('home/cabeceraAdmin');
        $this->load->view('home/articulos'); 
    }


    public function cargarClienteView() {
        $this->load->view('home/cabeceraAdmin');
        $this->load->view('home/ingUsuario'); 
    }

    
    public function GrabarArtiulo() {
        // Carga la biblioteca de carga de archivos
        $this->load->library('upload');
    
        // Configuración para la carga de la imagen
        $config['upload_path'] = './assets/media/';  // Ruta donde se guardarán las imágenes
        $config['allowed_types'] = 'jpg|jpeg|png|gif'; // Tipos de archivos permitidos
        $config['max_size'] = 2048; // Tamaño máximo en KB
        $config['overwrite'] = true; // Sobrescribe el archivo si ya existe
        $this->upload->initialize($config);
    
        $nombre_artic = $this->input->post('nombre');
        $descrip_artic = $this->input->post('descripcion');
        $precio_artic = $this->input->post('precio');
        $capacidad_artic = $this->input->post('cantidad');
        $fecha_artic = $this->input->post('fecha');
    
        // Intenta subir la imagen
        if ($this->upload->do_upload('imagen')) {
            $imagen_artic = $this->upload->data('file_name');
        } else {
            $imagen_artic = null;
        }
    
        // Verifica si los campos han sido completados
        if ($nombre_artic && $descrip_artic && $precio_artic && $capacidad_artic) {
            // Carga el modelo y guarda el artículo
            $this->load->model('InsertarArticulo');
            $this->InsertarArticulo->gurdarArticulo($nombre_artic, $descrip_artic, $precio_artic, $capacidad_artic, $fecha_artic, $imagen_artic);
            
            // Redirige a la lista de artículos
            redirect('OperarDatos/listarArtAdmin');
        } else {
            // Maneja el error: faltan campos
            $data['error'] = 'Por favor, completa todos los campos.';
            $this->load->view('home/articulos', $data); // Carga el formulario de nuevo con el mensaje de error
        }
    }
    
    
    


    // Carga en el arreglo $data_art los datos de la base de datos
    public function listarArt() {
        
        $this->load->model('InsertarArticulo');
        $data_art['artic'] = $this->InsertarArticulo->getArticulo();
        
        // Carga la vista para mostrar la lista de artículos
        $this->load->view('home/cabecera');
        $this->load->view('home/lista_articulos', $data_art);
    }



    // Carga en el arreglo $data_art los datos de la base de datos
    public function listarArtAdmin() {
        
        $this->load->model('InsertarArticulo');
        $data_art['artic'] = $this->InsertarArticulo->getArticulo();
        
        // Carga la vista para mostrar la lista de artículos
        $this->load->view('home/cabeceraAdmin');
        $this->load->view('home/lista_articulosAdmin', $data_art);
    }



       ///CARGA EL ARTICULO Y LA VIEW PARA ACTUALIZAR EL SHOW
       public function editarArticulo($nombre) {

        $this->load->library('session'); // Cargar la biblioteca de sesiones

        // Cargar el modelo
        $this->load->model('InsertarArticulo');
    
        // Obtener el artículo basado en el nombre
        $articulo = $this->InsertarArticulo->obtenerArticulo($nombre);
    
        // Verifica si el artículo existe
        if ($articulo) {
            $data['articulo'] = $articulo; // Pasa el artículo a la vista
            $this->load->view('home/cabeceraAdmin');
            $this->load->view('home/editarArticulo', $data); // Carga la vista de edición
        } else {
            // Mensaje de error si no se encuentra el artículo
            $this->session->set_flashdata('error', 'Artículo no encontrado.');
            redirect('operarDatos/listarArtAdmin'); // Redirige a la lista de artículos
        }
    }


    ///EDITA EFECTIVAMENTE EL SHOW
    public function actualizarArticulo() {

        $this->load->library('session'); 

        $nombre = $this->input->post('nombre');
        $descripcion = $this->input->post('descripcion');
        $precio = $this->input->post('precio');
        $capacidad = $this->input->post('capacidad');
        $fecha = $this->input->post('fecha');
    

        $this->load->model('InsertarArticulo');
    
      
        $resultado = $this->InsertarArticulo->actualizarArticulo($nombre, $descripcion, $precio, $capacidad,$fecha);
    
        if ($resultado) {
            
            $this->session->set_flashdata('success', 'Artículo actualizado exitosamente.');
        } else {
            // Mensaje de error
            $this->session->set_flashdata('error', 'No se pudo actualizar el artículo.');
        }
    
        // Redirigir a la lista de artículos
        redirect('operarDatos/listarArtAdmin');
    }
    
    



    ///BORRA UN SHOW
    public function borrarArticulo() {
        // Verificar si se recibió el nombre del artículo a borrar
        if ($this->input->post('nombre')) {
            $nombre = $this->input->post('nombre');
    
            // Cargar el modelo
            $this->load->model('InsertarArticulo');
    
            // Llamar a la función borrarArticulo del modelo
            $this->InsertarArticulo->borrarArticulo($nombre);
        }
    
        redirect('operarDatos/listarArtAdmin'); // Cambia esto a la ruta deseada
    }

    public function cargarMejoresShows() {
        $this->load->view('home/cabecera');
        $this->load->view('home/mejoresshows'); 
    }
    
}
