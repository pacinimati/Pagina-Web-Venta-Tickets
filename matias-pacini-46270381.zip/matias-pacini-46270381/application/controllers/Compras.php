<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Compras extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Funcion_model');
        $this->load->library('session'); 
    }

    // Muestra las funciones disponibles
    public function index() {
        $data['funciones'] = $this->Funcion_model->obtenerFuncionesDisponibles();
        $this->load->view('home/cabecera');
        $this->load->view('home/comprarFuncion', $data); 
    }

    // Procesar la compra
    public function comprar() {
        $nombre_funcion = $this->input->post('funcion');
        $cantidad = $this->input->post('cantidad');
        $nombre = $this->input->post('nombre'); 
        $dni = $this->input->post('dni'); 

        if ($this->input->server('REQUEST_METHOD') === 'POST') {

        if ($this->Funcion_model->hayEntradasDisponibles($nombre_funcion, $cantidad)) {

            $this->Funcion_model->registrarCompra($nombre, $dni, $nombre_funcion, $cantidad);


            ///resumen
            $data['funcion'] = $this->Funcion_model->obtenerFuncionPorNombre($nombre_funcion);
            $data['cantidad'] = $cantidad;
            $data['email'] = $nombre; // El correo electrónico ingresado en el formulario

             // Cargar vista de resumen con los datos de la compra
             $this->load->view('home/cabecera');
             $this->load->view('home/resumenCompra', $data);
             return; // Salir de la función para evitar la redirección final


        } else {
            $this->session->set_flashdata('error', 'No hay suficientes entradas disponibles');
        }
    }

        redirect('compras'); // Redirigir a la página de compras
    }

    public function comprarShow($nombre_show) {
        // Cargar la función específica por nombre (o puedes cambiar esto a ID si es más confiable)
        $data['funcion'] = $this->Funcion_model->obtenerFuncionPorNombre($nombre_show);
    
        if (!$data['funcion']) {
            show_404(); // Mostrar error 404 si no se encuentra el show
        }
    
        $this->load->view('home/cabecera');
        $this->load->view('home/comprarFuncionEspecifico', $data);
    }
    
}


