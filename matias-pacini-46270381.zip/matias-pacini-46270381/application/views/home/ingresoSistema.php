<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Ingresar al Sistema</title>
    <link rel="stylesheet" href="<?=base_url('assets/ingresoSistema.css');?>">
</head>
<body>
    <div class = "login-container" >
        <h3>INGRESAR AL SISTEMA</h3>
        <div class="form-container">
            <form action="<?= base_url(); ?>Iniciar/ValidaUsuario" method="POST">
                <p>Ingrese su Usuario</p>
                <input type="text" autofocus name="usuario" id="user" required autocomplete="off">  
                <p>Ingrese su Clave</p>  
                <input type="password" name="clave" id="pass" required autocomplete="off">
                <hr/>
                <div class = 'button-container'>
                <button type="submit">Entrar</button>
                </div>
                </div> 
                <br/>
            </form>      
            <div class = 'button-container'>
                <a href="<?php echo base_url('IngresoPagina'); ?>">
                <button>Volver a pagina anterior</button>
        </div>
    </div>

    <!-- Mensaje de error o confirmación -->
    
    <?php if (!empty($conforme)): ?>
        <h1 class="message-container"><?php echo $conforme; ?></h1>
    <?php endif; ?>
    
</body>
</html>
