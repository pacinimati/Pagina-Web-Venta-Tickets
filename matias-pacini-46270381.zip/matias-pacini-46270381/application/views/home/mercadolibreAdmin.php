<?php ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>TicketYa</title>
    <link rel="stylesheet" href="<?=base_url('assets/mercadoLibre.css');?>">
</head> 
<body>

    <section id="hero">
        <h1> USTED ESTA <br> EN MODO <br>ADMINISTRADOR! </h1>
    </section>

    <section id="SomosMercadoLibreGuitar">
      <div class="container">
        <div class="img-container"></div>
        <div class="texto">
        <h2>¡Somos <span 
            class="color-acento">TicketYa!<span></h2>
         <p>¡Bienvenido a TicketYa, tu destino de confianza para todas tus necesidades de entradas! Estamos aquí para ayudarte a encontrar los boletos perfectos para tus eventos favoritos, ya sean conciertos, espectáculos o eventos deportivos.

En TicketYa, ofrecemos una amplia selección de entradas para los mejores eventos, garantizando siempre la calidad y seguridad de tu compra. Nuestro catálogo incluye opciones para todos los gustos y presupuestos, asegurándote que encuentres la experiencia ideal. ¡No te pierdas la oportunidad de vivir momentos inolvidables!</p>
        </div>
    </div>
    </section>


   

    <footer>
        <div class="container">
        <p>&copy; TicketYa</p>
        </div> 
    </footer>

    <?php if (!empty($fragmento)): ?>
        <script>
            window.onload = function() {
                location.hash = '<?= $fragmento ?>';
            };
        </script>
    <?php endif; ?>

</body>
</html>
