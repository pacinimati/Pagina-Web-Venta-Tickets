<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?=base_url('assets/compras.css');?>">
    <title>Comprar Función</title>
</head>
<body>
    <h1>Comprar Función</h1>

    <?php if($this->session->flashdata('success')): ?>
        <p style="color: green;"><?php echo $this->session->flashdata('success'); ?></p>
    <?php endif; ?>

    <?php if($this->session->flashdata('error')): ?>
        <p style="color: red;"><?php echo $this->session->flashdata('error'); ?></p>
    <?php endif; ?>

    <form action="<?php echo base_url('compras/comprar'); ?>" method="post" onsubmit="return confirmPurchase()">
        <label for="funcion">Show seleccionado:</label>
        <input type="text" name="funcion" id="funcion" value="<?php echo htmlspecialchars($funcion->nombre, ENT_QUOTES, 'UTF-8'); ?>" readonly>

        <p><strong>Descripción:</strong> <?php echo htmlspecialchars($funcion->descripcion, ENT_QUOTES, 'UTF-8'); ?></p>
        <p><strong>Precio:</strong> <?php echo htmlspecialchars($funcion->precio, ENT_QUOTES, 'UTF-8'); ?></p>
        <p><strong>Fecha:</strong> <?php echo htmlspecialchars($funcion->fecha, ENT_QUOTES, 'UTF-8'); ?></p>
        
        <!-- Imagen del show seleccionado -->
        <div style="text-align: center;">
            <img src="<?= base_url('assets/media/'.$funcion->imagen); ?>" alt="Imagen de la función" style="width: 100px; height: 100px; object-fit: cover;">
        </div>
        
        <label for="cantidad">Cantidad de entradas:</label>
        <input type="number" name="cantidad" id="cantidad" min="1" required>

        <label for="nombre">Correo Electrónico:</label>
        <input type="text" name="nombre" id="nombre" required>

        <label for="dni">DNI:</label>
        <input type="text" name="dni" id="dni" required>

        <button type="submit">Comprar</button>
    </form>

    <script>
        function confirmPurchase() {
            return confirm("¿Estás seguro de que deseas realizar esta compra?");
        }
    </script>
</body>
</html>
