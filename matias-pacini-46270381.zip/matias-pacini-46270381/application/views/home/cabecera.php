<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Ticketeck</title>
    <link rel="stylesheet" href="<?=base_url('assets/mercadoLibre.css');?>">
</head> 
<body>
    <header>
        <div class="container">
        <a href="<?= base_url('ingresoPagina'); ?>">
                <img src="<?php echo base_url('assets/media/logoti.png'); ?>" alt="Logo MercadoLibreGuitar" class="logo-img">
            </a>
             <nav>
                <a href="<?= base_url('ingresoPagina'); ?>">Inicio</a>
                <a href="<?= base_url('operarDatos/cargarMejoresShows'); ?>">Galeria</a>
                
                <a href="<?= base_url('compras/comprar'); ?>">Comprar</a>
                <a href="<?= base_url('Iniciar/ValidaUsuario'); ?>">Ingresar</a>
             </nav>
        </div>
    </header>

  