<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resumen de Compra</title>
    <link rel="stylesheet" href="<?= base_url('assets/resumenCompra.css'); ?>">
</head>
<body>
    <br><br><br><br>
    <div class="resumen-compra-container">
        <h2>Resumen de Compra</h2>
        <p><strong>Función:</strong> <?= htmlspecialchars($funcion->nombre, ENT_QUOTES, 'UTF-8'); ?></p>
        <p><strong>Total a Pagar:</strong> $<?= htmlspecialchars($funcion->precio * $cantidad, ENT_QUOTES, 'UTF-8'); ?></p>
        <p><strong>Email de Destino:</strong> <?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?></p>
        <p><strong>Cantidad de Entradas:</strong> <?= htmlspecialchars($cantidad, ENT_QUOTES, 'UTF-8'); ?></p>
        <p><strong>Fecha:</strong> <?= htmlspecialchars($funcion->fecha, ENT_QUOTES, 'UTF-8'); ?></p>

        
        
        <a href="<?= base_url(); ?>" class="btn-volver">Volver al inicio</a>
    </div>
</body>
</html>
