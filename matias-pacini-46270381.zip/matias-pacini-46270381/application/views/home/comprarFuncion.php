<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= base_url('assets/compras.css'); ?>">
    <title>Comprar Función</title>
</head>
<body>
    <h1>Comprar Función</h1>

    <?php if($this->session->flashdata('success')): ?>
        <p style="color: green;"><?php echo $this->session->flashdata('success'); ?></p>
    <?php endif; ?>

    <?php if($this->session->flashdata('error')): ?>
        <p style="color: red;"><?php echo $this->session->flashdata('error'); ?></p>
    <?php endif; ?>

    <form action="<?php echo base_url('compras/comprar'); ?>" method="post" onsubmit="return confirmPurchase()">
        <div class="form-group">
            <label for="funcion">Show seleccionado:</label>
            <select name="funcion" id="funcion" onchange="updateDetails()">
                <?php 
                $primerImagen = null; 
                $primeraDescripcion = null;
                foreach($funciones as $index => $funcion): 
                    if ($index == 0) {
                        $primerImagen = $funcion->imagen;
                        $primeraDescripcion = $funcion->descripcion;
                        $primerPrecio = $funcion->precio;
                        $primerFecha = $funcion->fecha;
                    }
                ?>
                    <option value="<?php echo $funcion->nombre; ?>" data-imagen="<?php echo base_url('assets/media/'.$funcion->imagen); ?>" data-descripcion="<?php echo $funcion->descripcion; ?>" data-precio="<?php echo $funcion->precio; ?>" data-fecha="<?php echo $funcion->fecha; ?>">
                        <?php echo $funcion->nombre; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Descripción e imagen de la función seleccionada -->
        <div class="funcion-detalles">
            <p id="descripcion-funcion"><strong>Descripción:</strong> <span><?php echo $primeraDescripcion; ?></span></p>
            <p id="precio-funcion"><strong>Precio:</strong> <span><?php echo $primerPrecio; ?></span></p>
            <p id="fecha-funcion"><strong>Fecha:</strong> <span><?php echo $primerFecha; ?></span></p>
            <div style="text-align: center;">
                <img src="<?= base_url('assets/media/'.$primerImagen); ?>" alt="Imagen de la función" id="imagen-funcion" style="width: 120px; height: 120px; object-fit: cover;">
            </div>
        </div>

        <div class="form-group">
            <label for="cantidad">Cantidad de entradas:</label>
            <input type="number" name="cantidad" id="cantidad" min="1" required>
        </div>

        <div class="form-group">
            <label for="nombre">Correo Electrónico:</label>
            <input type="text" name="nombre" id="nombre" required>
        </div>

        <div class="form-group">
            <label for="dni">DNI:</label>
            <input type="text" name="dni" id="dni" required>
        </div>

        <button type="submit">Comprar</button>
    </form>

    <script>
        function updateDetails() {
            var select = document.getElementById("funcion");
            var imagen = select.options[select.selectedIndex].getAttribute("data-imagen");
            var descripcion = select.options[select.selectedIndex].getAttribute("data-descripcion");
            var precio = select.options[select.selectedIndex].getAttribute("data-precio");
            var fecha = select.options[select.selectedIndex].getAttribute("data-fecha");
            
            document.getElementById("imagen-funcion").src = imagen;
            document.getElementById("descripcion-funcion").querySelector("span").textContent = descripcion;
            document.getElementById("precio-funcion").querySelector("span").textContent = precio;
            document.getElementById("fecha-funcion").querySelector("span").textContent = fecha;
        }

        function confirmPurchase() {
            return confirm("¿Estás seguro de que deseas realizar esta compra?");
        }
    </script>
</body>
</html>
