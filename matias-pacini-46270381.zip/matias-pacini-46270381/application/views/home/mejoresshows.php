
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mejores Shows</title>
    <link rel="stylesheet" href="<?= base_url('assets/mejoresshows.css'); ?>">
</head>
<body>
    <br><br><br><br>
    <h1>Mejores Shows</h1>

    <div class="show-container">
        <div class="show">
            <h2>RED HOT CHILLI PEPPERS</h2>
            <p>ESTADIO: RIVER PLATE</p>
            <img src="<?= base_url('assets/media/show1.jpg'); ?>" alt="Show 1">
        </div>

        <div class="show">
            <h2>PAUL MCARNEY</h2>
            <p>ESTADIO: RIVER PLATE</p>
            <img src="<?= base_url('assets/media/show2.jpg'); ?>" alt="Show 2">
        </div>

        <div class="show">
            <h2>QUEEN</h2>
            <p>ESTADIO: VELEZ</p>
            <img src="<?= base_url('assets/media/show3.jpg'); ?>" alt="Show 3">
        </div>

        <div class="show">
            <h2>GUNS N' ROSES</h2>
            <p>ESTADIO: MOVISTAR ARENA</p>
            <img src="<?= base_url('assets/media/show4.jpg'); ?>" alt="Show 3">
        </div>
        <div class="show">
            <h2>GUSTAVO CERATI</h2>
            <p>ESTADIO: BOCA JUNIORS</p>
            <img src="<?= base_url('assets/media/show5.jpg'); ?>" alt="Show 3">
        </div>
        <div class="show">
            <h2>JIMI HENDRIX</h2>
            <p>ESTADIO: RACING CLUB</p>
            <img src="<?= base_url('assets/media/show6.jpg'); ?>" alt="Show 3">
        </div>
        <div class="show">
            <h2>CHARLY</h2>
            <p>ESTADIO: VELEZ</p>
            <img src="<?= base_url('assets/media/show7.jpg'); ?>" alt="Show 3">
        </div>
        <div class="show">
            <h2>ROLLING STONES</h2>
            <p>ESTADIO: RIVER PLATE</p>
            <img src="<?= base_url('assets/media/show3.jpg'); ?>" alt="Show 3">
        </div>
    </div>

</body>
</html>
