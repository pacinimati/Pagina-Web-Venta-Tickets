<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Productos</title>
    <link rel="stylesheet" href="<?= base_url('assets/listaArticulos.css'); ?>">
</head>

<body>
    <section class="contenido-princ">
        <h2><br>Lista de Shows</h2>

        <div id="tabla_artic">
            <table border="1" width="90%" align="center">
                <tr>
                    <th>Artista</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    <th>Fecha</th>
                    <th>Capacidad Restante</th>
                    <th>Acciones</th>
                </tr>
                <?php 
                // Verifica si hay artículos
                if ($artic && $artic->num_rows() > 0) {
                    foreach ($artic->result() as $articulo) {
                        // Solo muestra artículos válidos
                        if (!empty($articulo->nombre) && !empty($articulo->descripcion) && !empty($articulo->precio)) {
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($articulo->nombre); ?></td>
                                <td><?= htmlspecialchars($articulo->descripcion); ?></td>
                                <td><?= htmlspecialchars($articulo->precio); ?></td>
                                <td><?= htmlspecialchars($articulo->fecha); ?></td>
                                <td><?= htmlspecialchars($articulo->capacidad); ?></td>
                                <td>
                                    <form action="<?= base_url('OperarDatos/borrarArticulo'); ?>" method="POST" style="display:inline;">
                                        <input type="hidden" name="nombre" value="<?= htmlspecialchars($articulo->nombre); ?>">
                                        <button type="submit" onclick="return confirm('¿Estás seguro de que deseas eliminar este show?');" class="btn">Eliminar</button>
                                    </form>
                                    <a href="<?= base_url('OperarDatos/editarArticulo/' . str_replace(' ', '_', $articulo->nombre)); ?>" class="btn" >Modificar</a>

                                </td>
                            </tr>
                            <?php
                        }
                    }
                } else {
                    echo '<tr><td colspan="4">No hay artículos disponibles.</td></tr>';
                }
                ?>
            </table>
        </div>
        
    </section>

    <a href="<?php echo base_url('operarDatos/cargarArticuloView'); ?>">
                <button>Agregar show</button>
            </a>
    
    <br><br><br><br><br><br>

</body>
</html>
