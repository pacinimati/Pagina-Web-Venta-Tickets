<?php ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>TicketYa</title>
    <link rel="stylesheet" href="<?=base_url('assets/mercadoLibre.css');?>">
</head> 
<body>

    <section id="hero">
        <h1> COMPRA <br> CON LOS MEJORES <br>AQUI ABAJO! </h1>
    </section>

    <section id="SomosMercadoLibreGuitar">
      <div class="container">
        <div class="img-container"></div>
        <div class="texto">
        <h2>¡Somos <span 
            class="color-acento">TicketYa!<span></h2>
         <p>¡Bienvenido a TicketYa, tu destino de confianza para todas tus necesidades de entradas! Estamos aquí para ayudarte a encontrar los boletos perfectos para tus eventos favoritos, ya sean conciertos, espectáculos o eventos deportivos.
            En TicketYa, ofrecemos una amplia selección de entradas para los mejores eventos, garantizando siempre la calidad y seguridad de tu compra. Nuestro catálogo incluye opciones para todos los gustos y presupuestos, asegurándote que encuentres la experiencia ideal. ¡No te pierdas la oportunidad de vivir momentos inolvidables!</p>
        </div>
    </div>
    </section>


    <section id="NuestrasOpciones">
    <div class="container">
        <h2>Nuestros Shows</h2>
        <div class="opciones">
            <?php foreach ($artic as $articulo): ?>
                <div class="carta" style="background-image: linear-gradient(0deg, rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('<?php echo base_url("assets/media/".urlencode($articulo->imagen)); ?>');">
                    <h3><?php echo $articulo->nombre; ?></h3>
                    <p><?php echo $articulo->descripcion; ?></p>
                    <p><?php echo "Fecha: " . $articulo->fecha; ?></p>
                    <p><?php echo "Precio: " . $articulo->precio; ?></p>
                    <div class="button-container">
                        <a href="<?php echo base_url('compras/comprarShow/'.urlencode($articulo->nombre)); ?>">
                            <button>Comprar</button>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>




    <section id="caracteristicas">
        <div class="container">
        <ul>
            <li>✔️ 100% Recomendado con los mejores shows</li>
            <li>✔️ Fiable y Segura</li>
            <li>✔️ Asistencia de Servicio al cliente</li>
        </ul>
        </div>
    </section>


    <footer>
        <div class="container">
        <p>&copy; TicketYa</p>
        </div> 
    </footer>

    <?php if (!empty($fragmento)): ?>
        <script>
            window.onload = function() {
                location.hash = '<?= $fragmento ?>';
            };
        </script>
    <?php endif; ?>

</body>
</html>
