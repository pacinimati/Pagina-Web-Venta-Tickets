<?php ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar Usuarios</title>
    <link rel="stylesheet" href="<?= base_url('assets/listaArticulos.css'); ?>">
</head>

<body>
    <section class="contenido-princ">
        <h2><br>Lista de Compras</h2>

        <div id="tabla_users">
            <table border="1" width="90%" align="center">
                <tr>
                    <th>Cantidad</th>
                    <th>Correo Electronico</th>
                    <th>Dni</th>
                    <th>Funcion</th>
                    <th>Fecha</th>
                </tr>
                <?php 
                // Verifica si hay usuarios
                if (!empty($compras)) {
                    foreach ($compras as $compras) {
                        ?>
                        <tr>
                            <td><?= $compras->cantidad; ?></td>
                            <td><?= $compras->nombre; ?></td>
                            <td><?= $compras->dni; ?></td>
                            <td><?= $compras->funcion; ?></td>
                            <td><?= $compras->fecha; ?></td>
                        </tr>
                        <?php
                    }
                } else {
                    echo '<tr><td colspan="2">No hay usuarios disponibles.</td></tr>';
                }
                ?>
            </table>
        </div>
    </section>
</body>
</html>
