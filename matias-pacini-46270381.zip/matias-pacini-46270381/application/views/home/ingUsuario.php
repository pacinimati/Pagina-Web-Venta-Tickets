<?php ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carga de Artículos</title>
    <link rel="stylesheet" href="<?= base_url('assets/cargaArticulos.css'); ?>">
</head>
<body>
    <section class="form_carga">
        <br><br><br>
        <h3>Carga de USuarios</h3><br>
        <form action="<?= base_url(); ?>OperarDatos/GrabarCliente" method="POST">
            <input type="text" name="nombre" placeholder="Nombre del Usuario" required maxlength="40"><br><br>
            <input type="text" name="clave" placeholder="Clave" required maxlength="10"><br><br>
            <input type="submit" value="Cargar artículo">
        </form>
    </section>
</body>
</html>
