<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Ticketeck</title>
    <link rel="stylesheet" href="<?=base_url('assets/mercadoLibre.css');?>">
</head> 
<body>
    <header>
        <div class="container">
        <a href="<?= base_url('Modoadmin'); ?>">
                <img src="<?php echo base_url('assets/media/logoti.png'); ?>" alt="Logo MercadoLibreGuitar" class="logo-img">
            </a>
             <nav>

                <a href="<?= base_url('ingresoPagina'); ?>">Cerrar sesion</a>
                <a href="<?= base_url('operarDatos/listarArtAdmin'); ?>">Lista Shows</a>
                <a href="<?= base_url('MostrarUsers'); ?>">Lista Usuarios</a>
                <a href="<?= base_url('MostrarCompras'); ?>">Lista Compras</a>
             </nav>
        </div>
    </header>

  