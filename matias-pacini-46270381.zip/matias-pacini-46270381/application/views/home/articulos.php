<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carga de Artículos</title>
    <link rel="stylesheet" href="<?= base_url('assets/cargaArticulos.css'); ?>">
</head>
<body>
    <section class="form_carga">
        <br><br><br>
        <h3>Carga de Shows</h3><br>
        <form action="<?= base_url(); ?>OperarDatos/GrabarArtiulo" method="POST" enctype="multipart/form-data">
            <input type="text" name="nombre" placeholder="Nombre del show" required maxlength="40"><br><br>
            <input type="text" name="descripcion" placeholder="Descripción" maxlength="1000"><br><br>
            <input type="text" name="precio" placeholder="Precio" required maxlength="10"><br><br>
            <input type="text" name="cantidad" placeholder="Capacidad" required maxlength="10"><br><br>
            <input type="text" name="fecha" placeholder="Fecha" required maxlength="10"><br><br>
            <input type="file" name="imagen" accept="image/*" required><br><br> <!-- Campo para seleccionar la imagen -->
            <input type="submit" value="Cargar artículo">
        </form>
    </section>
</body>
</html>
