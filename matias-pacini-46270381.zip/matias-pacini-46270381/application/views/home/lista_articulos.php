<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Productos</title>
    <link rel="stylesheet" href="<?= base_url('assets/listaArticulos.css'); ?>">
</head>

<body>
    <section class="contenido-princ">
        <h2><br>Lista de Shows</h2>

        <div id="tabla_artic">
            <table border="1" width="90%" align="center">
                <tr>
                    <th>Artista</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    <th>Fecha</th>
                    <th>Imagen</th>
                </tr>
                <?php 
                // Verifica si hay artículos
                if ($artic && $artic->num_rows() > 0) {
                    foreach ($artic->result() as $articulo) {
                        // Solo muestra artículos válidos
                        if (!empty($articulo->nombre) && !empty($articulo->descripcion) && !empty($articulo->precio)) {
                            ?>
                            <tr>
                                <td><?= $articulo->nombre; ?></td>
                                <td><?= $articulo->descripcion; ?></td>
                                <td><?= $articulo->precio; ?></td>
                                <td><?= $articulo->fecha; ?></td>
                                <td>
                                    <?php if (!empty($articulo->imagen)) { ?>
                                        <img src="<?= base_url('assets/media/' . $articulo->imagen); ?>" alt="Imagen del show" width="100" height="100">
                                    <?php } else { ?>
                                        Sin imagen
                                    <?php } ?>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                } else {
                    echo '<tr><td colspan="5">No hay artículos disponibles.</td></tr>';
                }
                ?>
            </table>
        </div>
    </section>
    


</body>
</html>
