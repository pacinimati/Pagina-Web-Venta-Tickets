<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= base_url('assets/editarShows.css'); ?>">
    <title>Editar Artículo</title>
</head>
<body>
    <br><br><br><br>
<h3>Editar Artículo</h3>
<form action="<?= base_url('OperarDatos/actualizarArticulo'); ?>" method="POST">
    <input type="hidden" name="nombre_original" value="<?= $articulo->nombre; ?>">

    <label for="nombre">Nombre del artículo:</label><br>
    <input type="text" id="nombre" name="nombre" placeholder="Nombre del artículo" value="<?= $articulo->nombre; ?>" required maxlength="40"><br><br>

    <label for="descripcion">Descripción:</label><br>
    <input type="text" id="descripcion" name="descripcion" placeholder="Descripción" value="<?= $articulo->descripcion; ?>" maxlength="1000"><br><br>

    <label for="precio">Precio:</label><br>
    <input type="text" id="precio" name="precio" placeholder="Precio" value="<?= $articulo->precio; ?>" required maxlength="10"><br><br>

    <label for="capacidad">Capacidad:</label><br>
    <input type="text" id="capacidad" name="capacidad" placeholder="Capacidad" value="<?= $articulo->capacidad; ?>" required maxlength="10"><br><br>

    <label for="capacidad">Fecha:</label><br>
    <input type="text" id="fecha" name="fecha" placeholder="Fecha" value="<?= $articulo->fecha; ?>" required maxlength="10"><br><br>

    <input type="submit" value="Actualizar artículo">
</form>

</body>
</html>
