<?php ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar Usuarios</title>
    <link rel="stylesheet" href="<?= base_url('assets/listaArticulos.css'); ?>">
</head>

<body>
    <section class="contenido-princ">
        <h2><br>Lista de Usuarios</h2>

        <div id="tabla_users">
            <table border="1" width="90%" align="center">
                <tr>
                    <th>Nombre de Usuario</th>
                    <th>Contraseña</th>
                </tr>
                <?php 
                // Verifica si hay usuarios
                if (!empty($users)) {
                    foreach ($users as $user) {
                        ?>
                        <tr>
                            <td><?= $user->usuario; ?></td>
                            <td><?= $user->pass; ?></td>
                        </tr>
                        <?php
                    }
                } else {
                    echo '<tr><td colspan="2">No hay usuarios disponibles.</td></tr>';
                }
                ?>
            </table>
        </div>
    </section>

    <a href="<?php echo base_url('operarDatos/cargarClienteView'); ?>">
                <button>Agregar Admin</button>
            </a>
</body>
</html>
