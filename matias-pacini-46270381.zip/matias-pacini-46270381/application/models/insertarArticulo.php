<?php

class InsertarArticulo extends CI_Model {

    function __construct() { 
        parent::__construct();
        $this->load->database();
    }

// La funcion guarda nombre y apellido en la tabla clientes
public function gurdarArticulo($nombre_artic, $descrip_artic, $precio_artic, $capacidad_artic, $fecha_artic, $imagen_artic) {        
    $consulta = $this->db->query("INSERT INTO articulo (nombre, descripcion, precio, capacidad,fecha, imagen) VALUES ('$nombre_artic', '$descrip_artic', '$precio_artic', '$capacidad_artic', '$fecha_artic', '$imagen_artic')");
}



///Borrar articulo
public function borrarArticulo($nombre) {
    $this->db->where('nombre', $nombre);
    return $this->db->delete('articulo');
}

// Función para editar un artículo
public function editarArticulo($nombre, $data) {
    $this->db->where('nombre', $nombre);
    return $this->db->update('articulo', $data);
}

public function getArticulo(){
    $query=$this->db->get('articulo');
    if($query->num_rows()>0)
        return $query;
    else 
        return false;
}


public function actualizarArticulo($nombre, $descripcion, $precio, $capacidad, $fecha) {
    $this->db->where('nombre', $nombre);
    return $this->db->update('articulo', [
        'descripcion' => $descripcion,
        'precio' => $precio,
        'capacidad' => $capacidad,
        'fecha' => $fecha,

    ]);
}

public function obtenerArticulo($nombre) {
    $this->db->where('nombre', $nombre);
    $query = $this->db->get('articulo');

    if ($query->num_rows() > 0) {
        return $query->row(); // Devuelve una sola fila como objeto
    }
    return null; // Devuelve null si no se encuentra
}

public function getArticuloCant($limit = null) {
    $this->db->select('*');
    $this->db->from('articulo');
    
    if ($limit) {
        $this->db->limit($limit); // Limitar a 3 artículos
    }

    $query = $this->db->get();
    return $query->result(); 
}



 }













 
