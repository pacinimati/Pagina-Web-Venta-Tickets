<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserModel extends CI_Model {

 

    function __construct() { 
        parent::__construct();
        $this->load->database();
    }

  public function get_all_users(){
    $query = $this->db->get('user');
    return $query->result();
  }

}


