<?php
defined('BASEPATH') OR exit('No direct script access allowed');



///TODO LO RELACIONADO CON LAS COMPRAS DE SHOWS / FUNCIONES

class Funcion_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    // Obtener funciones (artículos) disponibles
    public function obtenerFuncionesDisponibles() {
        $this->db->where('capacidad >', 0);
        $query = $this->db->get('articulo'); 
        return $query->result();
    }

    // Verificar si hay entradas disponibles
    public function hayEntradasDisponibles($nombre_funcion, $cantidad) {
        $this->db->where('nombre', $nombre_funcion); 
        $query = $this->db->get('articulo');
        $funcion = $query->row();

        return $funcion && $funcion->capacidad >= $cantidad; // Verificar capacidad
    }

    // Registrar la compra
    public function registrarCompra($nombre, $dni, $nombre_funcion, $cantidad) {
        // Descontar las entradas
        $this->db->set('capacidad', 'capacidad - ' . (int)$cantidad, FALSE);
        $this->db->where('nombre', $nombre_funcion); 
        $this->db->update('articulo');

        // Registrar la compra
        $data = array(
            'nombre' => $nombre,
            'dni' => $dni,
            'funcion' => $nombre_funcion, 
            'cantidad' => $cantidad,
            'fecha' => date('Y-m-d H:i:s')
        );
        return $this->db->insert('compras', $data); 
    }

    public function obtenerFuncionPorNombre($nombre_show) {
        $this->db->where('nombre', $nombre_show);
        $query = $this->db->get('articulo');
        return $query->row(); // Devuelve un solo registro
    }
}




    

