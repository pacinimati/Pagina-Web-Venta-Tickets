<?php

class insertarCliente extends CI_Model {

    function __construct() { 
        parent::__construct();
        $this->load->database();
    }

// La funcion guarda nombre y apellido en la tabla clientes
public function guardarCliente($nombre,$clave){        
         $consulta = $this->db->query("INSERT INTO user (usuario,pass)   VALUES ('$nombre','$clave')");
}

  
 }













 
