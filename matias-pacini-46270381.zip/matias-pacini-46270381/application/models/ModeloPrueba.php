<?php

class ModeloPrueba extends CI_Model {

 

    function __construct() { 
        parent::__construct();
        $this->load->database();
    }

    function validaIngreso($usuario, $clave) {
        // Consulta a la tabla 'user' con los campos 'usuario' y 'pass'
        $query = "SELECT * FROM user WHERE usuario = ? AND pass = ?";
        
        // Usamos query binding para evitar SQL Injection
        $result = $this->db->query($query, array($usuario, $clave));
    
        // Verificamos si la consulta devolvió algún resultado
        if ($result->num_rows() > 0) {
            return $result;  // Devuelve el resultado si hay coincidencias
        } else {
            return false;  // Devuelve false si no hay coincidencias
        }
    }
     
}


