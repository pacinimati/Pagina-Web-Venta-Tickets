<?php
defined('BASEPATH') OR exit('No direct script access allowed');



///simplemente para ver las compras
class ComprasModel extends CI_Model {

 

    function __construct() { 
        parent::__construct();
        $this->load->database();
    }

  public function get_all_compras(){
    $query = $this->db->get('compras');
    return $query->result();
  }

}


